
function fetchPrayerTimesByLocation(lat, lon) {
  const today = new Date();
  const date = `${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}`;
  axios.get(`https://api.aladhan.com/v1/timings/${date}?latitude=${lat}&longitude=${lon}&method=2`)
    .then(response => {
      const timings = response.data.data.timings;
      document.getElementById("fajr").textContent = timings.Fajr;
      document.getElementById("dhuhr").textContent = timings.Dhuhr;
      document.getElementById("asr").textContent = timings.Asr;
      document.getElementById("maghrib").textContent = timings.Maghrib;
      document.getElementById("isha").textContent = timings.Isha;
      highlightNextPrayer(timings);
    })
    .catch(error => console.error("فشل في تحميل مواقيت الصلاة:", error));
}

function highlightNextPrayer(timings) {
  const now = new Date();
  const prayerNames = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"];
  let nextPrayer = null;
  let minDiff = Infinity;

  prayerNames.forEach(name => {
    const timeParts = timings[name].split(":");
    const prayerTime = new Date();
    prayerTime.setHours(parseInt(timeParts[0]), parseInt(timeParts[1]), 0);
    const diff = (prayerTime - now) / 1000;

    if (diff > 0 && diff < minDiff) {
      minDiff = diff;
      nextPrayer = name;
    }
  });

  if (nextPrayer) {
    const elements = {
      Fajr: document.getElementById("fajr").parentElement,
      Dhuhr: document.getElementById("dhuhr").parentElement,
      Asr: document.getElementById("asr").parentElement,
      Maghrib: document.getElementById("maghrib").parentElement,
      Isha: document.getElementById("isha").parentElement
    };
    elements[nextPrayer].classList.add("highlight-next");

    const hours = Math.floor(minDiff / 3600);
    const minutes = Math.floor((minDiff % 3600) / 60);
    document.getElementById("next-prayer").textContent =
      `🕰️ الوقت المتبقي للصلاة القادمة: ${hours} ساعة و ${minutes} دقيقة`;
  }
}

if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(
    (position) => {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;
      fetchPrayerTimesByLocation(lat, lon);
    },
    (error) => {
      console.error("خطأ في تحديد الموقع:", error);
      alert("⚠️ تأكد من تفعيل GPS للسماح للتطبيق بتحديد موقعك.");
    }
  );
} else {
  alert("❌ المتصفح لا يدعم تحديد الموقع الجغرافي.");
}
